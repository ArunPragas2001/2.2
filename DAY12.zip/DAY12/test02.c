#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    int index=372;

    int pipeAB[2],pipeBA[2];// A -> B and B ->A
    int pipeAC[2],pipeCA[2];

    pipe(pipeAB);
    pipe(pipeBA);
    pipe(pipeAC);
    pipe(pipeCA);

    int B =fork()
    {
        close(pipeAB[1]);
        close(pipeBA[0]);
        
        int num;
        read(pipeAB[0],&num,sizeof(num));
        close(pipeAB[0]);

        printf("Process B(PID=%d, PPID=%d)\n",getpid(),getppid());

       int n=num,sum=0;
       while(n>0){sum+= n%10; n/=10;}

       write(pipeBA[1],&sum,sizeof(sum));
       close(pipeBA[1]);

       return 0;   
    }

    int C = fork();

    if(C==0)
    {
        close(pipeAC[1]);
        close(pipeCA[0]);

        int num;
        read(pipeAC[0],&num, sizeof(num0));
        close(pipeAC[0]);

        printf("Process C(PID=%d,PPID=%d)\n",getpid(),getppid());

        int check= (num % 2 ==0) ? 1 : 0;

        write(pipeCA[1],&check,sizeof(check));

        close(pipeCA[1]);

        return 0; 

    }

    printf("Process A (PID=%d,PPID=%d),Index=%d\n",getpid(),getppid());

    close(pipeAB[0]);
    write(pipeAB[1],&index,sizeof(index));
    close(pipeAB[1]);


    close(pipeAC[0]);
    write(pipeAC[1],&index,sizeof(index));
    close(pipeAC[1]);

    close(pipeBA[1]);
    int sum;
    read(pipeBA[0],&sum,sizeof(sum));
    close(pipeBA[0]);


    close(pipeCA[1]);
    int check;
    read(pipeCA[0],&check,sizeof(check));
    close(pipeCA[0]);

    printf("Digit sum received from B%d\n", sum);

    if(check==1)
    printf("C says: %d is Even\n",index);
    else
    printf("C says: %d is Odd\n",index);
   
   return 0;
}