echo "hello"


factorial()
{
            
        fact=1

        while [ $num -gt 1 ];
        do 
            fact=$((fact * num));
            ((num--));
        done
        echo factorial is $fact;

}
read -p "enter a number: " num
factorial num;



