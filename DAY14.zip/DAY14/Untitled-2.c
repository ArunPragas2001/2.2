#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

char toUpper(char c) {
    if (c >= 'a' && c <= 'z')
        return c - 32;
    return c;
}

int main() {
    int p1[2], p2[2], p3[2];

    pipe(p1);
    pipe(p2);
    pipe(p3);

    float v1, v2, v3;
    char u1, u2, u3;

    printf("Enter three temperatures (e.g: 25C 77F 300K):\n");
    scanf("%f%c %f%c %f%c", &v1, &u1, &v2, &u2, &v3, &u3);

    u1 = toUpper(u1);
    u2 = toUpper(u2);
    u3 = toUpper(u3);

    // Child 1: C → F
    if (fork() == 0) {
        close(p1[0]);
        if (u1 == 'C') {
            v1 = (v1 * 9/5) + 32;
            u1 = 'F';
        }
        write(p1[1], &v1, sizeof(v1));
        write(p1[1], &u1, sizeof(u1));
        close(p1[1]);
        exit(0);
    }

    // Child 2: F → C
    if (fork() == 0) {
        close(p2[0]);
        if (u2 == 'F') {
            v2 = (v2 - 32) * 5/9;
            u2 = 'C';
        }
        write(p2[1], &v2, sizeof(v2));
        write(p2[1], &u2, sizeof(u2));
        close(p2[1]);
        exit(0);
    }

    // Child 3: K → C
    if (fork() == 0) {  
        close(p3[0]);   
        if (u3 == 'K') {    
            v3 = v3 - 273.15;   
            u3 = 'C';   
        }   
        write(p3[1], &v3, sizeof(v3));  
        write(p3[1], &u3, sizeof(u3));  
        close(p3[1]);   
        exit(0);    
    }   
    
    // Parent   
    close(p1[1]);
    close(p2[1]);
    close(p3[1]);

    wait(NULL);
    wait(NULL);
    wait(NULL);

    read(p1[0], &v1, sizeof(v1));
    read(p1[0], &u1, sizeof(u1));

    read(p2[0], &v2, sizeof(v2));
    read(p2[0], &u2, sizeof(u2));

    read(p3[0], &v3, sizeof(v3));
    read(p3[0], &u3, sizeof(u3));

    printf("\nConverted:\n");
    printf("%.2f%c\n", v1, u1);
    printf("%.2f%c\n", v2, u2);
    printf("%.2f%c\n", v3, u3);

    return 0;
}