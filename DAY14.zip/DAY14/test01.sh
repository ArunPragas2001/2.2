echo "Enter four-digit number"
read n

digitsum(n)
{   num=$1;
    result =0;

    while[ $num -gt 0 ]
    do
       result=$((result + num%10));
       num=$((num/10));
    done 
    echo $result;
}

digitsum $n;