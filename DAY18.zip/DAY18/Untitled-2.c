#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>

int main()
{
    int pipeA[2],int pipeB[2],int pipeC[2];

    if(pipe(pipeA)==-1 || pipe(pipeB)==-1  || pipe(pipeC)==-1){
        perror("pipe creattion failed");
        exit(EXIT_FAILURE);
    }

    pid_t pid1=fork();

    if(pid1<0)
    {
        perror("Fork Failed");
        exit(EXIT_FAILURE);
    }
    
    if(pid1>0)
    {
        close(pipeA[0]);
        close(pipeB[0]);close(pipeB[1]);
        close(pipeC[1]);
        
    }







}