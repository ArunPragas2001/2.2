/*create simplified version of a process hierachy and implement inter process communication 
IPC using pipes.

task

1.process A shalll read a single integer x from the user 
2.process A must then create one child process(B),
3.process B shall create two grandchild process (D and E)
4.Data must flow as follow 
A sends x to B
B calculates the square of x(x^2) and sends that result to both D and E

individual Process requirements

Process B: receive x from A, calculate x^2 and print :"Process B: Received[x],Square is[x^2]"
2.process D: receive the squared value from B and print it in Hexadecimal format
(Hint: use %x inside the printf function for converting to hexadecimal value);

3.process E:Receive the squared value from B and print it in Octal format 
(Hint: use 5o inside the printf function for converting to octal value )
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    int x;


    int pipeAB[2];

    
    int pipeBD[2];
    int pipeBE[2];

    pipe(pipeAB);
    pipe(pipeBD);
    pipe(pipeBE);

    
    printf("Enter a number: ");
    scanf("%d", &x);

    pid_t pidB = fork();


    if (pidB == 0)
    {
        int square;

        
        read(pipeAB[0], &x, sizeof(x));

        square = x * x;

        printf("Process B: Received [%d], Square is [%d]\n", x, square);

        
        pid_t pidD = fork();

        if (pidD == 0)
        {
            int value;

            
            read(pipeBD[0], &value, sizeof(value));

            printf("Process D: Hexadecimal value = %x\n", value);

            exit(0);
        }


        pid_t pidE = fork();

        if (pidE == 0)
        {
            int value;

            
            read(pipeBE[0], &value, sizeof(value));

            printf("Process E: Octal value = %o\n", value);

            exit(0);
        }

        
        write(pipeBD[1], &square, sizeof(square));
        write(pipeBE[1], &square, sizeof(square));

        wait(NULL);
        wait(NULL);
    }

    
    else
    {
        
        write(pipeAB[1], &x, sizeof(x));

        wait(NULL);
    }

    return 0;
}