#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>

int main()
{

    int x;

    int pipeAB[2];
    int pipeBD[2];
    int pipeBE[2];

    pipe(pipeAB);
    pipe(pipeBD);
    pipe(pipeBE);

    printf("Enter a number?");
    scanf("%d",&x);

    printf("A(PID:%d,PPID:%d)\n",getpid(),getppid());



    pid_t pidB=fork();

    if(pidB==0)
    {   
        int square;

        printf("B(PID:%d,PPID:%d)\n",getpid(),getppid());
        read(pipeAB[0],&x,sizeof(x));
        square= x*x;
        printf("Process B received [%d] squre is [%d]\n",x,square );




        if(fork()==0)
        {

          int valueX;
          printf("D(PID:%d,PPID:%d)\n",getpid(),getppid());
          read(pipeBD[0],&valueX,sizeof(valueX)); 
          printf("Proces D: hexadecimal value:%x\n",valueX);
          
         exit(0);
        }
        else if (fork()==0)
        {
          int valueO;
          printf("E(PID:%d,PPID:%d)\n",getpid(),getppid()); 
          read(pipeBE[0],&valueO,sizeof(valueO)); 
          printf("Proces E: octal value:%o\n",valueO);
          
        exit(0);
        }

        write(pipeBD[1],&square,sizeof(square));
        write(pipeBE[1],&square,sizeof(square));




        wait(NULL);
        wait(NULL);


    }
    else 
    {
        write(pipeAB[1],&x,sizeof(x));
        wait(NULL);
        wait(NULL);
    }





   return 0;




}