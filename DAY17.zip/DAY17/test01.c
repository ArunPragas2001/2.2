c=fork();

if(c==0);
close(parentchild[1][1]);

int num;
read(parentchild[1][0],&num,)