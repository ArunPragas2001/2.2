import express from 'express';
import bodyParser from "body-parser";


import moviesRoute from "./routes/movies.js";



const app=  express();
const PORT=3000;

app.listen(PORT,()=>{
    console.log(`Server is running on http://localhost:${PORT}`);
})

app.get("/",(req,res)=>{
    console.log("we are in the homepage now");
    res.send("Hello world")
})

app.use(bodyParser.json());


app.use('/movies',moviesRoute);






