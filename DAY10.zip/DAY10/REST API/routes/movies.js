import express from "express";
import {readFileSync, writeFileSync} from 'fs';
import{v4 as uuidv4} from "uuid";



let movies = JSON.parse(readFileSync('./movies.json','utf8'))


const router=express.Router();




router.get('/',(req,res)=>
{
    res.send(movies);
})

router.post("/",(req,res)=>{
    const movie={...req.body, id:uuidv4() };
    movies.push(movie);
    writeFileSync("./movies.json", JSON.stringify(movies, null, 2));
    res.send(`${movie.movieName}added`);
    
});

router.get("/:id",(req,res)=>
{
    const foundMovie = movies.find(
        movie=> movie.id===req.params.id
    );
    if (!foundMovie) {
    return res.status(404).send({ message: "Movie not found" });
  }
    res.send(foundMovie);
});


router.delete("/:id", (req, res) => {
  movies = movies.filter(
    movie => movie.id !== req.params.id
  );
  res.send("Movie deleted");
});





export default router;