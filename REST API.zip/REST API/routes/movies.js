import express from "express";
import{readFileSync} from "fs";
const router =express.Router();
const movies=JSON.parse(readFileSync('./movies.json','utf8'));
router.get('/',(req,res)=>
{
    res.send(movies);
})
export default router;

