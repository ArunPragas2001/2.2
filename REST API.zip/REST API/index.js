import express from "express";
import movies from "./routes/movies.js";
const app=express();
const PORT=3000;

app.use("/movies",movies);

app.listen(PORT,()=>{
    console.log(`server running on http://localhost:${PORT}`);
});

app.get("/",(req,res)=>{
    console.log("We are in the homepage");
    res.send("Hello");
});
