import dotenv from "dotenv";
dotenv.config();

import express from "express";
import bodyParser from "body-parser";
import mongoose from "mongoose";

const app = express();

const PORT = process.env.PORT || 8000;

app.use(bodyParser.json());

const MONGOURL = process.env.MONGO_URL;

console.log("Mongo URL:", MONGOURL);

mongoose.connect(MONGOURL)
.then(() => {
    console.log("Database connected successfully");
    app.listen(PORT, () => {
        console.log(`Server is running on port: ${PORT}`);
    });
}).catch((error) => console.log(error));