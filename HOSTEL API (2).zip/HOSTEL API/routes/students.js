import express from "express";
import {readFileSync, writeFileSync} from 'fs';
import{v4 as uuidv4} from "uuid";

let students = JSON.parse(readFileSync('./students.json','utf8'));

const router=express.Router();

router.get('/',(req,res)=>
{
    res.send(students);
})

router.post ("/",(req,res)=>{
   const student={...req.body, id:uuidv4()};
   students.push(student);
   writeFileSync("./students.json", JSON.stringify(students, null, 2));
   res.send(`${student.Name}added`);
})

router.get("/:id",(req,res)=>{
    const studentFound=students.find(
        student=>student.id===req.params.id
    );

    if(!studentFound)
    {
        return res.status(404).send({ message: "student not found" }); 
    }
    res.send(studentFound);
    });

    router.patch("/:id", (req, res) => {
        const studentFound = students.find(
          student => student.id === req.params.id
        );
      
        const { Name,roomNumber,course,checkInDate} = req.body;
      
        if (Name) studentFound.Name = Name;
        if (roomNumber) studentFound.roomNumber = roomNumber;
        if (course) studentFound.course = course;
        if (checkInDate) studentFound.checkInDate = checkInDate;
      
        res.send("student updated");
      });
      
      router.delete("/:id",(req,res)=>{
        students =students.filter(
            student=student.id!==req.params.id
        );
        res.send("student deleted")
      })






export default router;