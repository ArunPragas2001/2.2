import express from "express";
import { readFileSync, writeFileSync } from "fs";
import { v4 as uuidv4 } from "uuid";

let students = JSON.parse(
  readFileSync("./students.json", "utf8")
);


if (Array.isArray(students)) {
  const obj = {};
  students.forEach(s => {
    obj[s.id] = s;
  });
  students = obj;
}

const router = express.Router();

router.get("/", (req, res) => {
  res.send(students);
});

router.post("/", (req, res) => {
  const id = uuidv4();
  const student = { ...req.body, id };

  students[id] = student;

  writeFileSync("./students.json", JSON.stringify(students, null, 2));

  res.send(`${student.Name} added`);
});


router.get("/:id", (req, res) => {
  const studentFound = students[req.params.id];

  if (!studentFound) {
    return res.status(404).send({ message: "student not found" });
  }

  res.send(studentFound);
});


router.patch("/:id", (req, res) => {
  const studentFound = students[req.params.id];

  if (!studentFound) {
    return res.status(404).send({ message: "student not found" });
  }

  const { Name, roomNumber, course, checkInDate } = req.body;

  if (Name) studentFound.Name = Name;
  if (roomNumber) studentFound.roomNumber = roomNumber;
  if (course) studentFound.course = course;
  if (checkInDate) studentFound.checkInDate = checkInDate;

  students[req.params.id] = studentFound;

  writeFileSync("./students.json", JSON.stringify(students, null, 2));

  res.send("student updated");
});


router.delete("/:id", (req, res) => {
  if (!students[req.params.id]) {
    return res.status(404).send({ message: "student not found" });
  }

  delete students[req.params.id];

  writeFileSync("./students.json", JSON.stringify(students, null, 2));

  res.send("student deleted");
});

export default router;