import express from 'express';
import bodyParser from "body-parser";

import hostelRoute from "./routes/students.js";

const app= express();
const PORT=3000;

app.listen(PORT,()=>{
    console.log(`server running at http://localhost:${PORT}`);
})

app.get('/',(req,res)=>{
    console.log("we are in the homepage ");
    res.send("helloworld");
})






app.use(bodyParser.json());

app.use('/students',hostelRoute);